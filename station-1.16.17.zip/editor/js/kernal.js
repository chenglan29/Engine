game = {
    "stage":{},
    "$show":(obj)=>{
        game.stage[obj].draw.clearRect(0,0,window.innerWidth,window.innerHeight)
        game.stage[obj].role.forEach(item=>{
            if(item["类型"] == "几何角色"){
                game.stage[obj].draw.fillStyle=item["几何角色颜色"];
                game.stage[obj].draw.fillRect(item["几何角色LEFT"]*1,item["几何角色TOP"]*1,item["几何角色宽"]*1,item["几何角色高"]*1)
            }
        });
    }
};