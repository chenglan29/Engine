const fs = require("fs");


app.post('/buildProject', (req, res) => {
    logger.debug(req.body)
    res.status(200).json({
        success: true
    });
    if (fs.existsSync(`./debug/${req.body.project}/`) == false) fs.mkdirSync(`./debug/${req.body.project}/`);
    fs.mkdirSync(`./debug/${req.body.project}/${req.body.timestamp}`);
    var project = db("project")[req.body.project];
    if (project.type == "Web") {
        logger.debug(project)
        var res = "";
        res += `<!--name: ${project.name} -->\n`;
        res += `<!--description: ${project.desc} -->\n`;
        res += `<!--creator: ${project.creator} -->\n`;
        res += `<!--contributor: ${project.contributor} -->\n`;
        if (project.path[0]["是否使用HTML5"] != undefined && project.path[0]["是否使用HTML5"] != false)
            res += `<!DOCTYPE HTML>\n`;
        res += `<html>\n`;
        res += tab(1) + `<head>\n`;
        if (project.path[0]["字符集"] != undefined)
            res += tab(2) + `<meta charset="${project.path[0]["字符集"]}" />\n`;
        if (project.path[0]["页面标题"] != undefined)
            res += tab(2) + `<title>${project.path[0]["页面标题"]}</title>\n`;
        if (project.path[0]["页面上所有链接的默认 URL 和默认目标"] != undefined)
            res += tab(2) + `<base href="${project.path[0]["页面上所有链接的默认 URL 和默认目标"]}">\n`;
        if (project.path[0]["图标"] != undefined)
            res += tab(2) + `<link rel="icon" href="${project.path[0]["页面上所有链接的默认 URL 和默认目标"]}" />\n`;
        res += tab(2) + `<script src="/editor/js/kernal.js"></script>\n`
        res += tab(2) + `<link rel="stylesheet" href="/editor/css/kernal.css" />\n`;
        res += tab(1) + `</head>\n`;
        res += tab(1) + `<body ${build_attribute(project.path[0])}>\n`;
        if (project.path[0]["游戏作者联系信息"] != undefined)
            res += tab(2) + `<address>${project.path[0]["游戏作者联系信息"]}</address>\n`;
        res += build_tree(project.path[0].path, 2);
        res += tab(1) + `</body>\n`;
        res += `</html>`;
        logger.info(res);
        fs.writeFileSync(`./debug/${req.body.project}/${req.body.timestamp}/index.html`, res);
    }
});